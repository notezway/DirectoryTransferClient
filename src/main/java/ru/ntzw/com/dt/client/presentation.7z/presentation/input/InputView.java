package ru.ntzw.com.dt.client.presentation.input;

import com.airhacks.afterburner.views.FXMLView;

public class InputView extends FXMLView {
}
