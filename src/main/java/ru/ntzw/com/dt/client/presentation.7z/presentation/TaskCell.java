package ru.ntzw.com.dt.client.presentation;

import javafx.scene.Parent;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import ru.ntzw.com.dt.client.model.SendTask;
import ru.ntzw.com.dt.client.presentation.task.TaskPresenter;
import ru.ntzw.com.dt.client.presentation.task.TaskView;

public class TaskCell extends ListCell<SendTask> {

    private final Parent taskView;
    private final TaskPresenter taskPresenter;

    public TaskCell(SendTask task) {
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        TaskView container = new TaskView();
        taskView = container.getView();
        taskPresenter = (TaskPresenter) container.getPresenter();
        taskPresenter.setTask(task);
    }

    @Override
    protected void updateItem(SendTask task, boolean empty) {
        super.updateItem(task, empty);
        if(empty) {
            setGraphic(null);
        } else {
            setGraphic(taskView);
        }
    }

    public Parent getTaskView() {
        return taskView;
    }

    public TaskPresenter getTaskPresenter() {
        return taskPresenter;
    }
}
