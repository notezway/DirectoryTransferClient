package ru.ntzw.com.dt.client.presentation.task;

import com.airhacks.afterburner.views.FXMLView;

public class TaskView extends FXMLView {
}
