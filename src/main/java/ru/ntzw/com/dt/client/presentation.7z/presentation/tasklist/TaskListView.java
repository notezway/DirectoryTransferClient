package ru.ntzw.com.dt.client.presentation.tasklist;

import com.airhacks.afterburner.views.FXMLView;

public class TaskListView extends FXMLView {
}
