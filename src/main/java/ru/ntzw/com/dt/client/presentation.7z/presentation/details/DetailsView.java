package ru.ntzw.com.dt.client.presentation.details;

import com.airhacks.afterburner.views.FXMLView;

public class DetailsView extends FXMLView {
}
