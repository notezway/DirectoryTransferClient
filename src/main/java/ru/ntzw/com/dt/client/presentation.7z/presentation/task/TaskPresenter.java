package ru.ntzw.com.dt.client.presentation.task;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.HBox;
import ru.ntzw.com.dt.client.model.SendTask;
import ru.ntzw.com.dt.client.model.ServiceProvider;
import ru.ntzw.com.dt.client.presentation.UserInterface;

import javax.inject.Inject;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class TaskPresenter {

    @Inject
    private UserInterface userInterface;
    @Inject
    private ServiceProvider serviceProvider;

    public HBox root;
    public FontAwesomeIconView iconView;
    public Label nameLabel;
    public Label emailsLabel;
    public Label statusLabel;
    public ProgressBar progressBar;
    public Button button;

    private SendTask task;

    @FXML
    private void initialize() {
        nameLabel.setText("Name");
        statusLabel.setText("Progress");
    }

    public void onIconClicked(ActionEvent event) {
        if (task.isRunning()) {
            task.cancel();
        } else if (!task.getStatus().equals(SendTask.STATUS_FAILED)) {
            userInterface.getTaskListPresenter().removeTask(task);
        } else {
            Throwable throwable = task.getException();
            String details = "Отправка успешно завершена.";
            if (throwable != null) {
                details = getExceptionDetails(throwable);
            }
            openDetails(details);
        }
    }

    public SendTask getTask() {
        return task;
    }

    public void setTask(SendTask task) {
        if(this.task != null) return;
        this.task = task;
        nameLabel.textProperty().bind(task.titleProperty());
        emailsLabel.textProperty().bind(task.messageProperty());
        statusLabel.textProperty().bind(task.statusProperty());
        iconView.styleProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                System.out.println(newValue);
            }
        });
        task.statusProperty().addListener((observable, oldValue, newValue) -> {
            if(newValue.equals(SendTask.STATUS_PACKING)) {
                setIconView("FILE_ARCHIVE_ALT");
            } else if(newValue.equals(SendTask.STATUS_SENDING)) {
                setIconView("UPLOAD");
            }
        });
        progressBar.progressProperty().bind(task.progressProperty());
        task.setOnFailed(event -> {
            setIconView("CLOSE");
            openDetails(getExceptionDetails(event.getSource().getException()));
        });
        task.setOnCancelled(event -> setIconView("CLOSE"));
        task.setOnSucceeded(event -> setIconView("CHECK_CIRCLE_ALT"));
        new Thread(task).start();
    }

    private void openDetails(String details) {
        userInterface.newDetailsStage(
                task.getTitle(),
                task.getMessage(),
                task.getStatus(),
                details
        );
    }

    private void setIconView(String glyphName) {
        iconView.setGlyphName(glyphName);
    }

    private String getExceptionDetails(Throwable throwable) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(byteArrayOutputStream);
        throwable.printStackTrace(printStream);
        return byteArrayOutputStream.toString();
    }
}
